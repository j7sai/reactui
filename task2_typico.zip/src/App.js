import React,{Component} from 'react';
//import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
//import Greet from './components/Greet';
//import Message from './components/Message';
//import Welcome from './components/welcome';
import Dashboard from './components/Dashboard';
import { BrowserRouter as Route, Switch, BrowserRouter } from 'react-router-dom';
import ForclassAddrecipe from './components/ForclassAddrecipe';
class App extends Component{
  render(){
  return (
    <div className="App">
  <BrowserRouter>
        <Switch>
          <Route path="/dashboard/"><Dashboard/></Route>

          <Route path='/addnewrecipe/'>
          <Header/>
          <ForclassAddrecipe />
          </Route>
        </Switch>
  </BrowserRouter> 
    </div>
  );
  }
}

export default App;
