import React from 'react'


//function Greet(){
  //  return <h1> Hey!! plz work dont wast time</h1>
//}
const Greet =props => {
    console.log(props)
    return <h1>Hey babe this is {props.name}</h1>
}
export default Greet