import React,{Component} from 'react'
import AddnewRecipe from './Addnewrecipe'
import axios from 'axios';

class ForclassAddrecipe extends Component{
    constructor(props)
    {
        super()
        this.state={
           
            values:{
                recipename:'',
                ingridients:'',
                description:'',
                steps:'',
                },
        };
        this.handlername=this.handlername.bind(this);

    }
    handlername=(e)=>{
        const vname=e.target.name
        const vvalue=e.target.value
        this.setState(state=>{
            state.values[vname]=vvalue
            return {values:state.values} 

    });
    }
     

     save=()=>{

        const data = this.state.values
        console.log(this.state.values)
        axios.post('http://localhost:8000/foodrecipe/',data)
        .then(response => {
          console.log('Success')
          this.props.closePopUp()
        })
        .catch(error => {
            console.log(error)
        }) 
      }
    render()
    {
        return (
            <div>

                <AddnewRecipe handlername={this.handlername} save={this.save}/>

            </div>




        )
    }
}
export default ForclassAddrecipe