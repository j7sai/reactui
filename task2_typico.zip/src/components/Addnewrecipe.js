import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {TextField, DialogActions, FormControl} from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Dialog from '@material-ui/core/Dialog';
import Button from '@material-ui/core/Button';

// const useStyles = makeStyles(theme => ({
//   root: {
//     '& .MuiTextField-root': {
//       margin: theme.spacing(1),
//       width: 200,
//     },
//   },
// }));
const useStyles = makeStyles(theme => ({
  root: {
    
    '& .MuiTextField-root': {
      margin: theme.spacing(3),
      width: 300,
      
    
    },
    
    display: 'flex',
    flexWrap: 'wrap',
    paper: {
      padding: theme.spacing(2),
      marginTop: 114 ,
      color: theme.palette.text.secondary,
      maxWidth: 500,
    },
    
    
  },
  // paper: {
  //   padding: theme.spacing(2),
  //   textAlign: 'center',
  //   color: theme.palette.text.secondary,
  // },
  // textField: {
  //   marginLeft: theme.spacing(0),
  //   marginRight: theme.spacing(0),
  //   width: 800,

    
  // },
}));


export default function FormPropsTextFields(props) {
  const classes = useStyles();
  
  return (
    <React.Fragment>
    <form className={classes.root} noValidate autoComplete="off"  >
    <Grid container  justify='center'>
    <Paper className={classes.paper} style={{marginTop:114,background:'lightgrey'}}>
    <h1 style={{color:'violet',fontFamily:'Times New Roman'}}>Add Recipe
      
    </h1>

    <Grid container item direction='column' justify='center' >

        <Grid container item direction="row-reverse" justify="center" xs zeroMinWidth>    
         <Grid item > 
         <TextField
          id="standard-textarea"
          label="Ingridients"
          placeholder="Placeholder"
          name="ingridients"
          onChange={props.handlername}
          multiline
          
          />
        </Grid>
        <Grid item >
        <TextField
        required id="standard-required"  
        label=" Enter recipe name"
        name="recipename" 
        onChange={props.handlername}
        />
        </Grid>
        </Grid>

        <Grid container item lg={1} justify="center">
        <Grid item lg={3}>
        <TextField
          id="standard-full-width"
          label="Description"
          placeholder="Placeholder"
          style={{width:400}}
          name="description"
          onChange={props.handlername}
          fullWidth
          margin="normal"

           InputLabelProps={{
             shrink: true,
           }}
        />
        </Grid>
          </Grid>
        <Grid container item lg={1} justify="center">
          <Grid item lg={3}>
        <TextField
          id="standard-textarea"
          label="Steps"
          placeholder="Placeholder"
          style={{width:400}}
          name="steps"
          onChange={props.handlername}
          multiline
        /></Grid>
        </Grid>
    </Grid>
   
    
    <center>
     <Button type='Submit' color="primary" onClick={props.save}>
            Submit
            
          </Button>  
          </center>

    </Paper>
   
    </Grid>
   
    </form>
    </React.Fragment>
  );
}