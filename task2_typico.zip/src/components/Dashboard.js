import React,{Component} from 'react'
import Header from './Header';
import FoodRecipeList from './FoodRecipeList';
import Signup from './Signup';
import Login from './Login';
import axios from 'axios';

class Dashboard extends Component{
    constructor(props)
    {
        super()
        this.state={
            openPopUp:false,
            openlogPop:false,
            username:'',
            password:'',
            loginstatus:false
        }
    }
   handleClickOpen = () => {
        this.setState({openPopUp:true})
      };
    
    handleClose = () => {
        this.setState({openPopUp:false})
      };
    handlelogin=()=>{
        this.setState({openlogPop:true})
      };
    handlelogclose=()=>{
        this.setState({openlogPop:false})
      };
    handleaddrecipe(){
      alert('im sidebar');
    };
    handlechangelogname=(e)=>{
      this.setState({username:e.target.value});
    }
    handlechangepass=(e)=>{
      this.setState({password:e.target.value});
    }
    login=()=>{
      const username = this.state.username
      const password = this.state.password
      axios.post('http://localhost:8000/login/',{username:username,password:password})
      .then(response => {
        console.log('Success')
        this.closePopUp()
      })
      .catch(error => {
          console.log(error)
      }) 
    }
    render()
    {
        return (
            <div>
                <Header handlePopUp={this.handleClickOpen} loginStatus={this.state.loginstatus} handlelog={this.handlelogin} />
                <Signup openPopUp={this.state.openPopUp} closePopUp={this.handleClose}/>
              
                <Login openUp={this.state.openlogPop} closeUp={this.handlelogclose} uname={this.handlechangelogname} pass={this.handlechangepass} signin={this.login}/>
             
                <br/><br/><br/>
                <center>
                <FoodRecipeList />
                </center>
            </div>
        )
    }
}
export default Dashboard