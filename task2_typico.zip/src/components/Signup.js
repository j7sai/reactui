import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';


// const useStyles = makeStyles(theme => ({
//   root: {
//     '.MuiDialog-paperScrollPaper': {
//       display: flex,
//       width:500,    

//   },
//   },

// },

class Signup extends Component {
  constructor(props)
  {
      super()
      this.state={
          username:'',
          email:'',
          phoneno:'',
          password:'',
          date:new Date,
      
      }
  }
  handlechangename=(e)=>{
    this.setState({username:e.target.value});
  }
  handlechangeemail=(e)=>{
    this.setState({email:e.target.value});
  }
  handlechangephoneno=(e)=>{
    this.setState({phoneno:e.target.value});
  }
  handlechangepassword=(e)=>{
    this.setState({password:e.target.value});
  }
  handlechangedate=(e)=>{
    this.setState({date:e.target.value});
  }

  save=()=>{
    const data = this.state
    axios.post('http://localhost:8000/signup/',data)
    .then(response => {
      console.log('Success')
      this.props.closePopUp()
    })
    .catch(error => {
        console.log(error)
    }) 
  }
  render()
  {
  return (
   

    <div>
     
    <Dialog open={this.props.openPopUp}  onClose={this.props.closePopUp} aria-labelledby="form-dialog-title">
    <DialogTitle id="form-dialog-title">Sign Up</DialogTitle>
        <DialogContent>
          <TextField 
           margin="dense"
           id="username"
           label="Username"
           type="name"
           onChange={this.handlechangename}
           /><br/>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Email Address"
            type="email"
            onChange={this.handlechangeemail}
          /><br/>
          <TextField
           label='Phone Number'
           type='phone number'
           onChange={this.handlechangephoneno}
          /><br/>
          <TextField
           label='Password'
           type='password'
           onChange={this.handlechangepassword}
           /><br/>
           <TextField
           type='Date of Birth'
           type='date'
           onChange={this.handlechangedate}
           />
        
        </DialogContent>
        <DialogActions>
           <Button onClick={this.props.closePopUp} color="primary">
            Cancel
          </Button>
          <Button onClick={this.save} color="primary">
            Submit
          </Button> 
        </DialogActions>
        </Dialog>
    </div>
  );
}
}
export default Signup