import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
// import tileData from './tileData';
import axios from 'axios';

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    overflow: 'hidden',
    backgroundColor: theme.palette.background.paper,
  },
  gridList: {
    width: 1000,
    height: 950,
    // float:"right",
    // marginLeft:300,
    transform: 'translateZ(0)',
  },
}));


/**
 * 
 * The example data is structured as follows:
 *
 * import image from 'path/to/image.jpg';
 * [etc...]
 *
 * const tileData = [
 *   {
 *     img: image,
 *     title: 'Image',
 *     author: 'author',
 *     cols: 2,
 *   },
 *   {
 *     [etc...]
 *   },
 * ];
 */
const tileData=[
{
    "id": 1,
    "tag": [],
    "imagesrc": "http://127.0.0.1:8000/media/documents/Sample-Hospital-Software-Bill-MyOPD-Beds_R8UK4CN.jpg",
    "description": "",
    "createdDate": "2020-02-14",
    "user": 1,
    cols:1,
    rows:1
},
{
    "id": 2,
    "tag": [],
    "imagesrc": "http://127.0.0.1:8000/media/documents/1_mIPxTSp.jpg",
    "description": "",
    "createdDate": "2020-02-14",
    cols:1,
    rows:1

},
{
    "id": 3,
    "tag": [],
    "imagesrc": "http://127.0.0.1:8000/media/documents/Sample-Hospital-Software-Bill-MyOPD-Beds_R8UK4CN.jpg",
    "description": "",
    "createdDate": "2020-02-14",
    "user": 1,
    cols:2,
    rows:2

},
{
    "id": 4,
    "tag": [],
    "imagesrc": "http://127.0.0.1:8000/media/documents/Sample-Hospital-Software-Bill-MyOPD-Beds_VayyfKv.jpg",
    "description": "",
    "createdDate": "2020-02-14",
    cols:1,
    rows:1
}]
export default function ImageGridList() {
  const classes = useStyles();
  const [imageList, setImageList] = React.useState([]);

  axios.get('http://localhost:8000/images/')
  .then(response => {
    setImageList(response.data)
  })
  .catch(error => {
      console.log(error)
  }) 
  return (
    <div className={classes.root}>
      <GridList cellHeight={160} cols={4} spacing={1}  className={classes.gridList}>
        {tileData.map(item => (
          <GridListTile key={item.id} cols={tileData.cols} rows={tileData.rows}>
            <img src={item.imagesrc} alt="image" />
          </GridListTile>
        ))}
      </GridList>
    </div>
  );
}
