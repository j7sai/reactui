import React,{Component} from 'react'

class Message extends Component{
    constructor()
    {
        super()
        this.state={
            message:'to click'
        }
    }
    changeMess()
    {
        this.setState({
            message:'thanks for clicking subscribe button'
        }
        )
    }


    render()
    {
        return(
            <div>
             <h1>This is {this.state.message}</h1>
             <button onClick={()=>this.changeMessage()}>Subscribe</button>
             </div>
        )
    }
}
export default Message